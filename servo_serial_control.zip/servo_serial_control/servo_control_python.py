import serial
import time
arduino = serial.Serial(port='COM3', baudrate=115200, timeout=.1)
def send_oder(x):
    arduino.write(bytes(x, 'utf-8'))

while True:
    num = input("Enter Oder: ") # Taking input from user
    value = send_oder(num)
    time.sleep(0.05)
    v = arduino.readline()


    print(v) # printing the value 